package app.constants;

public class Messages {
    public static String NO_FILE_CHOSEN = "Nie wybrano żadnego pliku";
}
