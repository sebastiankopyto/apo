package app.gui.menu;

import javax.swing.*;

public class Lab2SubMenuGUI extends JMenu {
    public Lab2SubMenuGUI() {
        super("Lab2");
    }
}
