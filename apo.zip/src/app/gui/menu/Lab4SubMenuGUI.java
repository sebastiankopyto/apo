package app.gui.menu;

import javax.swing.*;

public class Lab4SubMenuGUI extends JMenu {
    public Lab4SubMenuGUI() {
        super("Lab4");
    }
}
